public class KubusImpl extends Kubus {
    public KubusImpl(String name) {
        super(name);
    }
}
